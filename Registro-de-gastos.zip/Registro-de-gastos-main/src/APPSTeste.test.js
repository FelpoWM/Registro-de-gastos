// Testes unitários para as funções de registro de gastos
// Arquivo: APPSTeste.test.js

// ─── Funções extraídas de APPSTeste.js para teste ────────────────────────────

let gastos = [];

function adicionarGasto(descricao, valor) {
    if (valor <= 0) {
        return false; // valor inválido
    }
    gastos.push({ descricao, valor });
    return true;
}

function listarGastos() {
    return gastos;
}

function calcularTotal() {
    return gastos.reduce((acc, gasto) => acc + gasto.valor, 0);
}

function limparGastos() {
    gastos = [];
}

// ─── Testes ──────────────────────────────────────────────────────────────────

describe('adicionarGasto()', () => {

    beforeEach(() => {
        limparGastos();
    });

    test('deve adicionar um gasto válido com sucesso', () => {
        const resultado = adicionarGasto('Almoço', 25);
        expect(resultado).toBe(true);
        expect(gastos).toHaveLength(1);
        expect(gastos[0]).toEqual({ descricao: 'Almoço', valor: 25 });
    });

    test('deve rejeitar gasto com valor zero', () => {
        const resultado = adicionarGasto('Café', 0);
        expect(resultado).toBe(false);
        expect(gastos).toHaveLength(0);
    });

    test('deve rejeitar gasto com valor negativo', () => {
        const resultado = adicionarGasto('Reembolso', -10);
        expect(resultado).toBe(false);
        expect(gastos).toHaveLength(0);
    });

    test('deve adicionar múltiplos gastos corretamente', () => {
        adicionarGasto('Almoço', 25);
        adicionarGasto('Transporte', 10);
        adicionarGasto('Cinema', 40);
        expect(gastos).toHaveLength(3);
    });

    test('deve armazenar a descrição corretamente', () => {
        adicionarGasto('Supermercado', 150.90);
        expect(gastos[0].descricao).toBe('Supermercado');
    });

    test('deve armazenar o valor corretamente', () => {
        adicionarGasto('Internet', 99.99);
        expect(gastos[0].valor).toBe(99.99);
    });
});

// ─────────────────────────────────────────────────────────────────────────────

describe('listarGastos()', () => {

    beforeEach(() => {
        limparGastos();
    });

    test('deve retornar lista vazia quando não há gastos', () => {
        expect(listarGastos()).toEqual([]);
    });

    test('deve retornar todos os gastos adicionados', () => {
        adicionarGasto('Almoço', 25);
        adicionarGasto('Transporte', 10);
        const lista = listarGastos();
        expect(lista).toHaveLength(2);
        expect(lista[0].descricao).toBe('Almoço');
        expect(lista[1].descricao).toBe('Transporte');
    });
});

// ─────────────────────────────────────────────────────────────────────────────

describe('calcularTotal()', () => {

    beforeEach(() => {
        limparGastos();
    });

    test('deve retornar 0 quando não há gastos', () => {
        expect(calcularTotal()).toBe(0);
    });

    test('deve calcular corretamente o total de um único gasto', () => {
        adicionarGasto('Almoço', 25);
        expect(calcularTotal()).toBe(25);
    });

    test('deve somar corretamente múltiplos gastos', () => {
        adicionarGasto('Almoço', 25);
        adicionarGasto('Transporte', 10);
        expect(calcularTotal()).toBe(35);
    });

    test('deve calcular total com valores decimais', () => {
        adicionarGasto('Café', 4.50);
        adicionarGasto('Lanche', 12.75);
        expect(calcularTotal()).toBeCloseTo(17.25);
    });

    test('deve calcular total de vários gastos corretamente', () => {
        adicionarGasto('Item A', 100);
        adicionarGasto('Item B', 200);
        adicionarGasto('Item C', 300);
        expect(calcularTotal()).toBe(600);
    });
});
