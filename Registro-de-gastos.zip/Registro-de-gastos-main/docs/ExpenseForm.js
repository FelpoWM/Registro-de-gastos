import React from 'react';

import './ExpenseForm.css';

const ExpenseForm = () => {
    return (
    <form> 
        <div className="new-expense__controls">
            <div className='new-expense__control'>
                <label>Title</label>
                <input Type='text'/>
            </div>
        </div>
        <div className="new-expense__controls">
            <div className='new-expense__control'>
                <label>Amount</label>
                <input Type='number' min="0.01" step="0.01"/>
            </div>
        </div>
        <div className="new-expense__controls">
            <div className='new-expense__control'>
                <label>Date</label>
                <input Type='date' min="2019-01-01" max="2023-12-31"/>
            </div>
            <div className="new-expense__actions">
                <button type="submit">Add Expense</button>
            </div>
        </div>
    </form>
)
};

export default ExpenseForm;